import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;

/**
 * Write a description of class Dragon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Dragon extends Props
{
    public Dragon(){
        Random rnd = new Random();
        this.setImage("Dragon"+ rnd.nextInt(3)+".png");
    }
    public void act()
    {
        jalanHilang();
    }
}
