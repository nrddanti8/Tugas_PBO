import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;

/**
 * Write a description of class Cloud here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cloud extends Props
{
    public Cloud(){
        Random rnd = new Random();
        this.setImage("awan"+ rnd.nextInt(4)+".png");
    }
    public void act()
    {
        this.setLocation(this.getX()-1, this.getY());
        if(this.getX()<=0){
            World wrld = this.getWorld();
            wrld.addObject(new Cloud(), wrld.getWidth()-1,new Random().nextInt(wrld.getHeight()-1));
            wrld.removeObject(this);
        }
    }
}
