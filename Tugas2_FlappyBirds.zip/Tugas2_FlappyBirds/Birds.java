import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Birds here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Birds extends Player
{
    /**
     * Act - do whatever the Birds wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Birds()
    {
        this.setImage(new GreenfootImage("Sbirds1.png"));
    }
    
    int lastNameNo = 1;
    int animationDelay = 10;
    void animate(){
        if(animationDelay<10){
            animationDelay++;
            return;
        }
        animationDelay = 0;
        if(lastNameNo==4){
            lastNameNo = 1;
        }
        else{
            lastNameNo++;
        }
        
        this.setImage(new GreenfootImage("Sbirds"+lastNameNo+".png"));
        
    }
    private int vSpeed = 0;
private int acceleration = 1;
private int jumpHeight = -5; 
public void act()
{
    animate();
    mover();
    fall();
}
public void mover()
{
    if(Greenfoot.isKeyDown("Up"))
    {
        vSpeed = jumpHeight;
        fall();
    }
}
private void fall()
{
    setLocation(getX(), getY() + vSpeed);
    vSpeed = vSpeed + acceleration;
}
}
