import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Sea here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sea extends World
{

    /**
     * Constructor for objects of class Sea.
     * 
     */
    public Sea()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 700, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Fish fish = new Fish();
        addObject(fish,65,628);
        fish.getY();
        fish.setLocation(131,340);
        Fish1 fish1 = new Fish1();
        addObject(fish1,288,559);
        Fish2 fish2 = new Fish2();
        addObject(fish2,650,182);
        Fish3 fish3 = new Fish3();
        addObject(fish3,428,248);
    }
}
