import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    
    public MyWorld()
    {    
        super(900,500, 1);
        prepare();

        GreenfootImage img = new GreenfootImage("Sky.png");
        this.setBackground(img);

        this.addObject(new Birds(), 200,200);
        Random rnd = new Random ();
        for(int i = 0; i<5; i++){
            this.addObject(new Cloud(), rnd.nextInt(this.getWidth()-1), rnd.nextInt(this.getHeight()-1));
        }
    }
    private void prepare()
    {
        Player player = new Player();
        addObject(player,116,503);
    }
}
