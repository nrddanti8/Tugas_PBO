import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
import java.util.Random;

public class MyWorld extends World
    
{
    private int currentLevel = 1;
    public MyWorld()
    {
        super(800, 600, 1);
        prepare();
    }
    public void act()
    {
        if(getObjects(ObjectSpecial.class).isEmpty()){
            if(currentLevel == 3){
                currentLevel++;
                showText("Game Over - You Win!", getWidth()/2, getHeight()/2);
                Greenfoot.stop();
            }
        }
    }
    public void prepare()
    {
        this.addObject(new Character(), 200,200);
        Random rnd = new Random();
        for(int i = 0; i<5; i++){
            this.addObject(new ObjectSpecial(), rnd.nextInt(this.getWidth()-1), rnd.nextInt(this.getHeight()-1));
            setPaintOrder(ObjectSpecial.class);
        }
        for(int i = 0; i<5; i++){
            this.addObject(new Enemy(), rnd.nextInt(this.getWidth()-1), rnd.nextInt(this.getHeight()-1));
            setPaintOrder(Enemy.class);
        }
    }
    public void nextLevel(){
        removeObjects(getObjects(ObjectSpecial.class));
        prepare();
    }
}
