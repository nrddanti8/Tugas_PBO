import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Character here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Character extends Actor
{
    private int score = 0;
    private GreenfootImage[] characterImages;
    private int animationIndex = 0;
    public Character()
    {
        characterImages = new GreenfootImage[8];
        for(int i = 1; i < 8; i++){
            characterImages[i] = new GreenfootImage("Man" + i + ".png");
        }
        setImage(characterImages[0]);
    }
    private int vSpeed = 0; 
    private int jumpHeight = -5;
    public void act()
    {
        mover();
        animateCharacter();
        checkForCollision();
    }
    public void animateCharacter()
    {
        if(animationIndex < 3){
            animationIndex++;
        }else {
            animationIndex = 0;
        }
        setImage(characterImages[animationIndex]);
    }
    public void checkForCollision(){
        Actor object = getOneIntersectingObject(ObjectSpecial.class);
        if(object != null){
            increaseScore();
            getWorld().removeObject(object);
        }
    }
    public void increaseScore(){
        score += 10;
        getWorld().showText("Score: " + score, 50, 25);
    }
    public void mover()
{
    if (Greenfoot.isKeyDown("left"))
        turn(-8);
        
    if (Greenfoot.isKeyDown("right"))
        turn(8);     
            
    if (Greenfoot.isKeyDown("up"))
        move(2);
            
    if (Greenfoot.isKeyDown("down"))
        move(-2); 
}
}
